#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"

struct syscallPage_entry
{
    unsigned syscallNumber;
    unsigned noOfArguments;
    unsigned status;
    long argsArr[6];
    unsigned returnValue;
};

// Assuming one page is enough for one process
struct syscallPage_info
{
    unsigned noOfEntries;
    struct page_entry *entry; // first entry pointer
    char *basePointer;
};

unsigned main()
{
    struct syscallPage_info *page;
    page->basePointer = kalloc(); // if possible we can use sbrk() instead of kalloc to initialize a page table in the user address space
    page->noOfEntries = 128;      // each entry is a set of values from the structure syscallPage_entry, whose size is 32bytes.
                                  // so 4096/32 = 128 entries
    puschcli(); //is it more optimal to do it here?
    for()
}